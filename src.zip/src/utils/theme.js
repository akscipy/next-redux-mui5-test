import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    // Customize Material-UI with your theme
    // See more here: https://material-ui.com/customization/themes/
    mode: 'dark',
    // mode: 'light',
  }
})

export default theme
