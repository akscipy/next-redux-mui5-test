import { INCREMENT, DECREMENT, SET_TREND_PANEL_DATA } from '../constants'
import { HYDRATE } from 'next-redux-wrapper'

export const initialState = {
  value: 0,
  action: null,
  from: null,
  trendPanelData: [],
}

export const counter = (state = initialState, action) => {
  switch (action.type) {
    case HYDRATE:
      return {
        ...state,
        ...action.payload
      }

    case INCREMENT:
      return {
        ...state,
        value: state.value + 1,
        action: 'increment',
        from: action.from
      }

    case DECREMENT:
      return {
        ...state,
        value: state.value - 1,
        action: 'decrement',
        from: action.from
      }

    case SET_TREND_PANEL_DATA:
      return {
        ...state,
        trendPanelData: action.data,
      }

    default:
      return {...state}
  }
}
