import * as React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';

const columns = [
  { field: 'Pair', headerName: 'Pair', width: 200},
  { field: 'M15', headerName: 'M15', width: 80},
  { field: 'H1', headerName: 'H1', width: 80},
  { field: 'H4', headerName: 'H4', width: 80},
  { field: 'H12', headerName: 'H12', width: 80},
  { field: 'D', headerName: 'D', width: 80 },
  { field: 'W', headerName: 'W', width: 80},
  { field: 'Price', headerName: 'Price', width: 250},
  { field: '%24Hr', headerName: '%24Hr', width: 250},
  { field: 'Volume', headerName: 'Volume', width: 200},
  { field: 'Chart', headerName: 'Chart', width: 200},
  { field: 'M16', headerName: 'M16', width: 200},
];

const rows = [
  { Pair: 1, M15: <ArrowDropUpIcon/>, H1: 'Jon', H4: 35, H12: 1, D: 'Snow', W: 'Jon', Price: "$35", id: 1, Volume: 'Snow', Chart: 'Jon', M16: 35 },
];

export default function DataTable() {
  return (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={rows}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5]}
      />
    </div>
  );
}
