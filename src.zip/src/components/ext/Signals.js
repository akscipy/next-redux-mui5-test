import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Container from '@mui/material/Container';
import SignalCellularAltOutlinedIcon from '@mui/icons-material/SignalCellularAltOutlined';
import ChevronRightOutlinedIcon from '@mui/icons-material/ChevronRightOutlined';
import useStyles from './Style';


function createData( pair, signal, price) {
  return { pair, signal, price };
}

const rows = [
  createData('XTZUSD', 12, 6.0, 24),
  createData('ADAUSD', 1.234, 9.0, 37),
  createData('ETHUSD', 2.912, 16.0, 24),
  createData('LINKUSD', 305, 3.7, 67),
];
export default function Signal() {
  const classes = useStyles();
  return (
    <>
<Container>
<Grid container>
  <TableContainer component={Paper} className={classes.container}>
<h4 className='Tableheading'> <SignalCellularAltOutlinedIcon />SIGNALS</h4>
<Table aria-label="simple table">
        <TableHead className={classes.theader}>
          <TableRow>
            <TableCell>Pair</TableCell>
            <TableCell>Signal</TableCell>
            <TableCell>Price</TableCell>
          </TableRow>
        </TableHead>
        <TableBody className={classes.tbody}>
          {rows.map((row) => (
            <TableRow
              key={row.pair}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.pair}
              </TableCell>
              <TableCell>{row.signal}</TableCell>
              <TableCell>{row.price}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    <h4 className='details'>Details <ChevronRightOutlinedIcon /> </h4>
</Grid>
    </Container>
    </>
  );
}
