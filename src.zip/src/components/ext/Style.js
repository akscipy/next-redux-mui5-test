import { makeStyles } from "@mui/styles";
import { borderRadius } from "@mui/system";

const useStyles = makeStyles({
    theader: {
      background: '#ececec',
      padding: '0 30px',
      '& th':{
          fontWeight:'800'
      }
    },
    tbody:{
        '& tr:nth-child(4)':{
            borderBottom:'1px solid #cacaca',
        },
        '& th,td':{
            fontWeight:'800'
        }
    },
    container: {
        padding: '16px 16px 0px 16px;',
        boxShadow: 'none',
    },
    box:{
        background:'#fff',
        padding:'20px',
        borderRadius:'6px',
    },
    tabbtn:{
        '& button':{
        background:'#ececec',
        minHeight:'45px',
        color:'#707070',
        borderRadius:'6px',
        },
    },
    btngrid:{
paddingLeft:'75px !important',
'& button':{
    background:'#ececec',
    color:'#707070',
},
'& button:hover':{
background:'#ececec',

}
    },
    grid:{
        display: 'flex',
    alignItems: 'baseline',
    position:'relative',
    top:'-7px',
    paddingLeft:'44px !important'
    },
    icon:{
        position:'relative',
        top:'8px',
        margin:'5px',
    },
    datatable:{
        height:'400px',
        width:'100%',
        '& header':{
            background:'#000'
        }
    }
  });
export default useStyles  