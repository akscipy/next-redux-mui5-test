import * as React from 'react';
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Tableone from './Tableone';
import Tabletwo from './Tabletwo';
import Tablethree from './Tablethree';
import TrackChangesIcon from '@mui/icons-material/TrackChanges';
import DownloadIcon from '@mui/icons-material/Download';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Grid from '@mui/material/Grid';
import FormControl from '@mui/material/FormControl';
import Button from '@mui/material/Button';
import ShareIcon from '@mui/icons-material/Share';
import { Settings } from '@mui/icons-material';
import { Dashboard } from '@mui/icons-material';
import { Person } from '@mui/icons-material';

import useStyles from './Style';


function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p:1 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

export default function BasicTabs() {
  const classes = useStyles();
  const [age, setAge] = React.useState('');
  const handleChangee = (event) => {
    setAge(event.target.value);
  };
   const [exchange, setexchangee] = React.useState('');
   const [pair, setpair] = React.useState('');
  const handleChangeone = (event) => {
    setexchangee(event.target.value);
  };
  const handleChangesec = (event) => {
    setpair(event.target.value);
  };

  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: '100%' }} >
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }} >
        <Tabs value={value} onChange={handleChange} aria-label="basic tabs example" className={classes.tabbtn}>
          <Tab icon={<Dashboard />} iconPosition="start" label="Standard" {...a11yProps(0)} ></Tab>
          <Tab icon={<Settings />} iconPosition="start" label="Customize" {...a11yProps(1)} />
          <Tab icon={<Person />} iconPosition="start" label="Profile" {...a11yProps(2)} />
        </Tabs>
      </Box>
<Grid className={classes.box}>
      <Grid container spacing={1}>
    <h3  className='scannerbuttonheading'> <TrackChangesIcon />Scanner</h3>
        <Grid item xs={8} className={classes.btngrid}>
       <Button variant="contained" spacing={1}>Trend</Button>
      <Button variant="contained">Price to MA</Button>
      <Button variant="contained">MA Cross</Button>
      <Button variant="contained">RSI</Button>
      <Button variant="contained">FSR</Button>
      <Button variant="contained">Stoch cross</Button>
      <Button variant="contained">Macd</Button>
      <Grid item xs={6}>
      <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }}>
        <InputLabel id="demo-simple-select-standard-label">Select MA</InputLabel>
        <Select
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={age}
          onChange={handleChangee}
          label="Age"
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
      <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }}>
        <InputLabel id="demo-simple-select-standard-label">Select Cross Length</InputLabel>
        <Select
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={age}
          onChange={handleChangee}
          label="Age"
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
        </Grid>
        </Grid>
        <Grid item xs={3} className={classes.grid}>
      <FormControl variant="standard" sx={{ m: 1, minWidth: 60 }}>
        <InputLabel id="demo-simple-select-standard-label">Pair</InputLabel>
        <Select
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={age}
          onChange={handleChangee}
          label="Age"
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
      <FormControl variant="standard" sx={{ m: 1, minWidth: 90}}>
        <InputLabel id="demo-simple-select-standard-label">Exchange</InputLabel>
        <Select
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={age}
          onChange={handleChangee}
          label="Age"
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
  <DownloadIcon className={classes.icon} />
      <ShareIcon className={classes.icon}/>
      </Grid>
      </Grid>

      <TabPanel value={value} index={0}>
      <Tableone/>
      </TabPanel>
      <TabPanel value={value} index={1}>
      <Tabletwo/>
      </TabPanel>
      <TabPanel value={value} index={2}>
      <Tablethree/>
      </TabPanel>
      </Grid>
    </Box>
  );
}
