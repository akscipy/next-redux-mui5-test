import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Container from '@mui/material/Container';
import ChevronRightOutlinedIcon from '@mui/icons-material/ChevronRightOutlined';
import useStyles from './Style';


function createData( pair,price, hour, volume) {
  return { pair, price, hour, volume };
}

const rows = [
  createData('XTZUSD', 12, 6.0, '$2.40M'),
  createData('ADAUSD', 1.234, 9.0, '$1.90M'),
  createData('ETHUSD', 2.912, 16.0, '$900.40M'),
  createData('LINKUSD', 305, 3.7, '$223.40M'),
];

export default function Topcoin() {
  const classes = useStyles();
  return (
    <>
<Container>
<Grid container>
  <TableContainer component={Paper} className={classes.container}>
  <h4 className='Tableheading'><i className="fa-brands fa-btc"></i> TOP BULL COINS</h4>
      <Table aria-label="simple table">
        <TableHead className={classes.theader}>
          <TableRow>
            <TableCell>Pair</TableCell>
            <TableCell>Price</TableCell>
            <TableCell>%24HR</TableCell>
            <TableCell>Volume</TableCell>
          </TableRow>
        </TableHead>
        <TableBody className={classes.tbody}>
          {rows.map((row) => (
            <TableRow
              key={row.pair}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.pair}
              </TableCell>
              <TableCell>{row.price}</TableCell>
              <TableCell>{row.hour}</TableCell>
              <TableCell>{row.volume}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    <h4 className='details'>Details <ChevronRightOutlinedIcon /> </h4>
</Grid>
    </Container>
    </>
  );
}
