import React from 'react'
import { styled } from '@mui/material/styles';
import { Box, Paper, Grid, Drawer, Typography } from '@mui/material';
import { makeStyles } from '@mui/styles';

import { connect } from 'react-redux';
import { set_trend_panel_data } from '@/src/actions';
import { bindActionCreators } from 'redux';

import { SET_TREND_PANEL_DATA } from '@/src/constants';

// import Dashboard from '@/src/components/dashboard/Dashboard';
// import Appbar from '@/src/components/dashboard/Appbar';
// import Navbar from '@/src/components/dashboard/Navbar';

const drawerWidth = 240;

const useStyles = makeStyles({
  drawer: {
    width: drawerWidth,
  },
  drawerPaper: {
    width: drawerWidth,
  },
  root: {
    display: 'flex',
  }
})


const Index = ({
  trendPanelData,
  actions: {
    set_trend_panel_data,
  },
}) => {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <Drawer
        className={classes.drawer}
        variant="permanent"
        anchor="left"
        classes={{paper: classes.drawerPaper}}
       >
        <div>
          <Typography variant="h5">
            Live Crypto Scanner
          </Typography>
        </div>
      </Drawer>
    </div>
  )
}

Index.getInitialProps = async ({ store }) => {
  await store.dispatch(set_trend_panel_data())
  return {}
}

export default connect(
  state => state,
  dispatch => ({ actions: bindActionCreators({ set_trend_panel_data }, dispatch) })
)(Index)
