import axios from 'axios'
import { INCREMENT, DECREMENT, SET_TREND_PANEL_DATA } from '../constants'

export const increment = (isServer) => {
  console.log('payload');
  return dispatch => {
    dispatch({
      type: INCREMENT,
      from: isServer ? 'server' : 'client'
    })
  }
}

export const decrement = (isServer) => {
  return dispatch => {
    dispatch({
      type: DECREMENT,
      from: isServer ? 'server' : 'client'
    })
  }
}

export const set_trend_panel_data = (payload) => {
  return async dispatch => {
    let x0 = {
      data: []
    };
    try {
      // x0 = await axios.get('http://localhost:3004/trend');
      // x0 = await axios.get('http://my-json-server.typicode.com/akscipy/test-json-server/trend');
      x0 = await axios.get('http://my-json-server.typicode.com/LiveCryptoScanner/mock-json-server/trend');
      console.log(x0.data);
    } catch (err) {
      console.log(err);
    }

    dispatch({
      type: SET_TREND_PANEL_DATA,
      data: x0.data
    })
  }
}
