import React from 'react'

import { connect } from 'react-redux'
import { set_trend_panel_data } from '@/src/actions'
import { bindActionCreators } from 'redux'


import Layout from '@/src/components/layout/Layout';

const Index = ({
  trendPanelData,
  actions: {
    set_trend_panel_data,
  }
}) => {
  return (
    <div>
      <Layout />
    </div>
  )
}

Index.getInitialProps = async ({ store }) => {
  await store.dispatch(set_trend_panel_data())
  return {}
}

export default connect(
  state => state,
  dispatch => ({ actions: bindActionCreators({ set_trend_panel_data }, dispatch) })
)(Index)
