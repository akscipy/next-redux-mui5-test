import React from 'react'
// import makeStyles  from '@material-ui/styles/makeStyles'
// import Card from '@material-ui/core/Card'
// import CardActions from '@material-ui/core/CardActions'
// import CardContent from '@material-ui/core/CardContent'
// import Fab from '@material-ui/core/Fab'
// import AddIcon from '@material-ui/icons/Add'
// import RemoveIcon from '@material-ui/icons/Remove'
// import Typography from '@material-ui/core/Typography'

// import reportWebVitals from './reportWebVitals';

import { connect } from 'react-redux'
import { set_trend_panel_data } from '../src/actions'
import { bindActionCreators } from 'redux'

import { INCREMENT, SET_TREND_PANEL_DATA } from '../src/constants'

import TestComponent from '../src/components/test/testComp1';
import Header from '../src/components/ext/Header';

const Index = ({
  trendPanelData,
  actions: {
    set_trend_panel_data,
  }
}) => {
  return (
    <div>
      <Header />
    </div>
  )
}

Index.getInitialProps = async ({ store }) => {
  await store.dispatch(set_trend_panel_data())
  return {}
}

export default connect(
  state => state,
  dispatch => ({ actions: bindActionCreators({ set_trend_panel_data }, dispatch) })
)(Index)
